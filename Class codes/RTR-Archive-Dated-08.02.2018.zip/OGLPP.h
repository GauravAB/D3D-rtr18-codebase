#pragma once

#define IDBITMAP_KUNDALI 100
#define IDBITMAP_STONE   101
